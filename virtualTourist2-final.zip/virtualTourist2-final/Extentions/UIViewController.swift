//
//  UIViewController.swift
//  virtualTourist
//
//  Created by Raed Faraj on 6/21/19.
//  Copyright © 2019 Udacity. All rights reserved.
//

import UIKit

extension UIViewController {
    // Mark (1) : Extention to display error message that may be thrown during using the app.

    func displayAlertMessages(title : String, message : String?) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
        self.present(alert, animated: true , completion: nil)
    }
    
}
