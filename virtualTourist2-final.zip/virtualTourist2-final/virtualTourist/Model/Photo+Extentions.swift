//
//  Photo+Extentions.swift
//  virtualTourist
//
//  Created by Raed Faraj on 6/21/19.
//  Copyright © 2019 Udacity. All rights reserved.
//

import Foundation
import UIKit

extension Photo {
    func set(image : UIImage) {
        //self.image = image.pngData()
        self.imageData = image.pngData()
    }
    
    func getImage() -> UIImage? {
      //  return ( image == nil) ? nil : UIImage(data : image!)

        return ( imageData == nil) ? nil : UIImage(data : imageData!)
    }
    
    public override func awakeFromInsert() {
        super.awakeFromInsert()
        creationDate = Date()
    }
}
