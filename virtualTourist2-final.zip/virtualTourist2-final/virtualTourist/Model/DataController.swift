//
//  DataController.swift
//  virtualTourist
//

// DataController used to keep data delegate tidy. We need to set up the stack where the data first start up. This class used to encapsulate the stack setup and functionality
//  Created by Raed Faraj on 6/15/19.
//  Copyright © 2019 Udacity. All rights reserved.
//

import Foundation
import CoreData // Must be imported

// Make it class insted of struct because we will pass it between viewControllers. this will prevent make multiple copy when do this.

class DataController {
    // hold persistent Container instance
    
    // define singlton
    static let sharedDataController = DataController()
    
    let persistentContainer = NSPersistentContainer(name : "VirtualTourist") // shouldn't be change during the life of dataContrller
    
    // computed properties to access the context
    var viewContext : NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    

    
    
    // to help us load the presistnat store using the persistnat container
    
    //Mark: load used to call load persistant store function
   // func load(completion : (()->Void)? = nil){
        func load() {
        persistentContainer.loadPersistentStores { (storeDescription, error) in
            
            // If there is error loading the store display error
            guard error == nil else {
                fatalError(error!.localizedDescription)
            }
            // call the completion function
        }
    }
    
    // help us access the context
}
