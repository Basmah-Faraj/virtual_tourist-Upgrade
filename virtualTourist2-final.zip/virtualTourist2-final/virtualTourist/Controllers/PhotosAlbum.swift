//
//  PhotosAlbum.swift
//  virtualTourist
//
//  Created by Raed Faraj on 6/14/19.
//  Copyright © 2019 Udacity. All rights reserved.
//

import UIKit
import MapKit
import CoreData


class PhotosAlbum: UIViewController , NSFetchedResultsControllerDelegate , MKMapViewDelegate{
    
    // Mark (Outlet Defination)
    @IBOutlet weak var smallMapView: MKMapView!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var newCollectionButton: UIBarButtonItem!
    @IBOutlet weak var deletedButton: UIBarButtonItem!
    
    
    // Mark (Global Varibale)
    var pin: Pin!
    var fetchResultController : NSFetchedResultsController<Photo>!

    var pageNumber = 1
    var isdeletingEverything = false
    var context : NSManagedObjectContext {
        return DataController.sharedDataController.viewContext
    }
    
    // Mark(ViewDidLoad)
    override func viewDidLoad() {
        initiliseUI()
        guard let pin = pin else {
            return
        }
        showLocation(pin)
        setupFetchResultController(pin)
    }
    
    // Mark (3) : Set all UI elements for first use.
    func initiliseUI()
    {
        // Set the small map
        smallMapView.delegate = self
        smallMapView.isZoomEnabled = true
        smallMapView.isScrollEnabled = false
        
        // Hide the label message and activity Indicator
        messageLabel.isHidden = true
        messageLabel.text = ""
        activityIndicator.isHidden = true
    }
    
    // Mark (4): show Location function get the Pin and display it on the map
    private func showLocation(_ pin: Pin) {
        
        // Get latitude and longitude for specific pin and create a coordinate
        let latitude = Double(pin.latitude)
        let longitude = Double(pin.longitude)
        let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        
        // Define an annotiation and set the value
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        
        // Reset the map
        smallMapView.removeAnnotations(smallMapView.annotations)
        smallMapView.addAnnotation(annotation)
        smallMapView.setCenter(coordinate, animated: true)
    }
    
    
    // Mark (View Did Dissapear):  To clear fetch controller when user close the app
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        // Remove photos when closing the page
        fetchResultController = nil
    }
    
    // Mark (doWeHavePhoto) : Check if there is photos
    var doWeHavePhoto : Bool {
        return (fetchResultController.fetchedObjects?.count ?? 0) != 0
    }
    
    // Mark : Retrive images from Fliker
    func setupFetchResultController(_ pin: Pin) {
        
        let fetchRequest: NSFetchRequest<Photo> = Photo .fetchRequest()
        let predicate = NSPredicate(format: "pin == %@ AND isDeletedImage = NO", pin)
        fetchRequest.predicate = predicate
        let sortDescriptor = NSSortDescriptor(key: "creationDate", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: "pin")
        
        fetchResultController.delegate = self
        
        do {
            try fetchResultController.performFetch()
            if doWeHavePhoto {
                activityIndicator.stopAnimating()
                updateUI(processing : false)
            } else {
                newCollectionButtonClicked(self)
            }
        } catch {
            fatalError(" Fatel error: Fetch faild \(error.localizedDescription)")
        }
    }
    
    @IBAction func deletedIconClicked(_ sender: Any) {

        performSegue(withIdentifier: "deletedPhoto", sender: pin)
    }
    

    
    @IBAction func newCollectionButtonClicked(_ sender: Any) {
        updateUI(processing: true)
        if doWeHavePhoto {
            isdeletingEverything = true
            for photo in fetchResultController.fetchedObjects! {
                photo.isDeletedImage = true
                try? context.save()
            }
            try? context.save()
            isdeletingEverything = false
        }
        
        FlickrAPI.getPhotoURLs(with: pin.coordinate, pageNumber: pageNumber) { (urls, error, errorMessage) in
            DispatchQueue.main.async {
                self.updateUI(processing : false)
                guard ( error == nil ) && ( errorMessage == nil) else {
                    self.displayAlertMessages(title: "Error", message: error?.localizedDescription ?? errorMessage)
                    return
                }
                
                guard let urls = urls, !urls.isEmpty else {
                    self.messageLabel.text = "Unfortunatly, There is no photos"
                    self.messageLabel.isHidden = false
                    return
                }
                
                for url in urls {
                    let photo = Photo(context: self.context)
                    photo.imageURL = url
                    photo.pin = self.pin
                }
                try? self.context.save()
            }
        }
        pageNumber += 1
     }
    
    func updateUI(processing: Bool) {
        collectionView.isUserInteractionEnabled = !processing
        if processing {
            newCollectionButton.title = "Fetching photo"
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
            newCollectionButton.title = "New Collection"
        }
    }

    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        messageLabel.isHidden = (controller.fetchedObjects?.count ?? 0 ) > 0
       collectionView.reloadData()
        
    }
    
    
    // Mark ( Prepare ) : set the segue
    override func prepare( for segue: UIStoryboardSegue,sender: Any?) {
        print("prepare for segue")
        if ((segue.destination as? DeletedPhotos) != nil) {
            guard (sender as? Pin) != nil else {
                return
            }
            let photoAlbumViewController = segue.destination as! DeletedPhotos
            photoAlbumViewController.pin = sender as? Pin
            
        }
        
    }
    
    }


// Mark (): Extention to handle all collectionView functions.
extension PhotosAlbum : UICollectionViewDelegate , UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fetchResultController.fetchedObjects?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell
        cell.showActivityIndicatorView()

        let photo = fetchResultController.object(at: indexPath)
        cell.locationPhoto.image = nil
        cell.urlString = photo.imageURL?.absoluteString
        if let data = photo.imageData, let cachedImage = UIImage(data: data) {
            cell.hideActivityIndicatorView()
            cell.locationPhoto.image = cachedImage
        } else {
            URLSession.shared.dataTask(with: photo.imageURL!) { (data, response, error) in
                if let error = error {
                    print(error.localizedDescription)
                    return
                    
                }
                guard let data = data, let DownloadedImage  = UIImage(data: data) else { return }
                photo.imageData = data
                DispatchQueue.main.async {
                    cell.locationPhoto.image = DownloadedImage
                }
                }.resume()
        }
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let photo = fetchResultController.object(at: indexPath)

       // context.delete(photo)
        photo.isDeletedImage = true
        try? context.save()
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width - 20) / 4
        return CGSize(width: width, height: width)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }

}


