//
//  DeletedPhotos.swift
//  virtualTourist
//
//  Created by Raed Faraj on 7/5/19.
//  Copyright © 2019 Udacity. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class DeletedPhotos: UIViewController,  NSFetchedResultsControllerDelegate  {
    
    
    @IBOutlet weak var CollectionView: UICollectionView!
    
    var pin: Pin!
    var fetchResultController : NSFetchedResultsController<Photo>!


    var context : NSManagedObjectContext {
        return DataController.sharedDataController.viewContext
    }

    override func viewDidLoad() {
        guard let pin = pin else {
            return
        }
        setupFetchResultController(pin)
        CollectionView.reloadData()

    }

    // Mark (View Did Dissapear):  To clear fetch controller when user close the app
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        // Remove photos when closing the page
        fetchResultController = nil
    }
    
    // Mark (doWeHavePhoto) : Check if there is photos
    var doWeHavePhoto : Bool {
        return (fetchResultController.fetchedObjects?.count ?? 0) != 0
    }
    
    func setupFetchResultController(_ pin: Pin) {
        print("Setup")
        let fetchRequest: NSFetchRequest<Photo> = Photo .fetchRequest()
        let predicate = NSPredicate(format: "pin == %@ AND isDeletedImage = YES", pin)
        fetchRequest.predicate = predicate
        let sortDescriptor = NSSortDescriptor(key: "creationDate", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: "pin")
        
        fetchResultController.delegate = self
        
        do {
            try fetchResultController.performFetch()
            if doWeHavePhoto {
                updateUI(processing : false)
            } else {
            }
        } catch {
            fatalError(" Fatel error: Fetch faild \(error.localizedDescription)")
        }
    }
    
    func updateUI(processing: Bool) {
        
        CollectionView.isUserInteractionEnabled = !processing
        print("updateUI")
        
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        CollectionView.reloadData()
        
    }
    
}

extension DeletedPhotos : UICollectionViewDelegate , UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fetchResultController.fetchedObjects?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell

        let photo = fetchResultController.object(at: indexPath)
        
        print(photo)
        cell.locationPhoto.image = nil
        cell.urlString = photo.imageURL?.absoluteString
        if let data = photo.imageData, let cachedImage = UIImage(data: data) {
            cell.locationPhoto.image = cachedImage
        } else {
            URLSession.shared.dataTask(with: photo.imageURL!) { (data, response, error) in
                if let error = error {
                    print(error.localizedDescription)
                    return

                }
                guard let data = data, let DownloadedImage  = UIImage(data: data) else { return }
                photo.imageData = data
                DispatchQueue.main.async {
                    cell.locationPhoto.image = DownloadedImage
                }
                }.resume()
        }
        return cell
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width - 20) / 4
        return CGSize(width: width, height: width)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
}
