//
//  ViewController.swift
//  virtualTourist
//
//  Created by Raed Faraj on 6/11/19.
//  Copyright © 2019 Udacity. All rights reserved.
//

import UIKit
import MapKit
import CoreData

class TravelLocationsMapViewController: UIViewController, MKMapViewDelegate, NSFetchedResultsControllerDelegate {

    // Mark (outlets definition)
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var bottomView: UIView!
    
    // Mark ( Varibales Definations)
    var pinAnnotation: MKPointAnnotation? = nil
    var fetchResultController : NSFetchedResultsController<Pin>!

    // Mark ( Context) : Can be deleted and return using the long name DataController.sha...
    var context : NSManagedObjectContext {
        return DataController.sharedDataController.viewContext
    }
    
    // Mark (ViewDidLoad)
    override func viewDidLoad() {
        super.viewDidLoad()
        initilizeUI()
    }
    
    // Mark ( initilizeUI ) : set UI element for first use.
    func initilizeUI() {
        navigationItem.rightBarButtonItem = editButtonItem
        bottomView.isHidden = true
        bottomView.backgroundColor = .red
    }
    
    // Mark ( viewWillAppear)
    override func viewWillAppear(_ animated: Bool) {
        super .viewWillAppear(animated)
        setupFetchResultController()
    }
    
    // Mark ( viewDidDisappear)
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        fetchResultController = nil
        
    }
    
    // Mark (SetEditing) : if the user click edit button
    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        bottomView.isHidden = !editing
    }
    
    // Mark (Setup Fetch Result Controller ): Get all pins on the map
    func setupFetchResultController() {
        let fetchRequest: NSFetchRequest<Pin> = Pin.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "creationDate", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]

        fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: "pin")

        fetchResultController.delegate = self

        do {
            try fetchResultController.performFetch()
            UpdateMapView()
        } catch {
            fatalError(" Fatel error: Fetch faild \(error.localizedDescription)")
        }
    }
    
    // Mark ( long Press ) : Handle long press Geture
    @IBAction func longPress(_ sender: UILongPressGestureRecognizer) {
        
        if sender.state != .began { return }
        let touchPoint =  sender.location(in: mapView)
        
        let pin = Pin(context:  context)
        // Get cordination
        pin.coordinate = mapView.convert(touchPoint, toCoordinateFrom: mapView)
        try? context.save()
        
        UpdateMapView()

    }
    
    // Mark: Update Map View : update the pins on the map
    func UpdateMapView()
    {
        guard let pins = fetchResultController.fetchedObjects else { return }
        for pin in pins {
            // Make sure it's not exist
            if mapView.annotations.contains(where: { pin.compare(to: $0.coordinate)}) {continue}
            let annotation = MKPointAnnotation()
            annotation.coordinate = pin.coordinate
            mapView.addAnnotation(annotation)
            
            }
        }
    
    // Mark ( Prepare ) : set the segue
    override func prepare( for segue: UIStoryboardSegue,sender: Any?) {
        
        if ((segue.destination as? PhotosAlbum) != nil) {
            guard (sender as? Pin) != nil else {
                return
            }
            let photoAlbumViewController = segue.destination as! PhotosAlbum
            photoAlbumViewController.pin = sender as? Pin
            
        }
        
    }
   
    // Mark ( controllerWillChangeContent ) : track changes on the Data and update the map
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        UpdateMapView()
    }
    
    // Mark ( did select ) : handle click on pins
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        
        guard let annotation = view.annotation else {
            return
        }
        
        if isEditing {
            let lat = String(annotation.coordinate.latitude)
            let lon = String(annotation.coordinate.longitude)
            
            if let pin = FetchPin(latitude: lat, longitude: lon) {
                context.delete(pin)
                try? context.save()
                mapView.removeAnnotation(annotation)
                return
            }
        } else {
            let pin = fetchResultController.fetchedObjects?.filter { $0.compare(to : view.annotation!.coordinate)}.first!
            performSegue(withIdentifier: "showPhotos", sender: pin)
        }
        mapView.deselectAnnotation(annotation, animated: true)
    }
    
    // Mark ( fetch Pin ) : Get a pin when selectd to be deleted
    private func FetchPin(latitude: String, longitude: String) -> Pin? {
        var pin: Pin?
        let fetchRequest: NSFetchRequest<Pin> = Pin.fetchRequest()

        fetchRequest.predicate = NSPredicate(format: "latitude == %@ AND longitude == %@", latitude, longitude)
        let sortDescriptor = NSSortDescriptor(key: "creationDate", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]

        do
        {
            pin = (try context.fetch(fetchRequest) ).first
        } catch {
            fatalError(" Fatel error: Fetch faild \(error.localizedDescription)")

        }
        return pin
    }
    
    // Mark set Annotation
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let reuseId = "pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = false
            pinView!.pinTintColor = .red
            pinView!.animatesDrop = true
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            
        } else {
            pinView!.annotation = annotation
        }
        return pinView
        
    }
}

