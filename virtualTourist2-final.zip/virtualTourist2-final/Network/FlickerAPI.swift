//
//  FlickerAPI.swift
//  virtualTourist
//
//  Created by Raed Faraj on 6/15/19.
//  Copyright © 2019 Udacity. All rights reserved.
//

import Foundation
import MapKit

class FlickrAPI {
    
    
    static func getPhotoURLs(with coordinate: CLLocationCoordinate2D, pageNumber: Int, completion: @escaping ([URL]?, Error?, String?) -> ()) {
        
        let URLParameters = [ "method"         : "flickr.photos.search"
            , "api_key"        : "e642c34c6ac8532ef77a7ec1c221babc"
            , "format"         : "json"
            , "extras"         : "url_m"
            , "nojsoncallback" : "1"
            , "safe_search"  : "1"
            , "bbox"    :  getBboxInfo(latitude: coordinate.latitude, longitude: coordinate.longitude)
            , "per_page" : 9
            , "page"          : pageNumber
            ] as [String : Any ]
        
        
        let request = URLRequest( url: constructURL(from: URLParameters))
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            guard (error == nil) else {
                completion(nil,error,nil)
                return
            }
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                completion(nil,nil,"statusCode")
                return
            }
            
            guard let data = data else {
                completion(nil,error,nil)
                return
            }
            
            print(String(data: data, encoding: .utf8)!)
            
            guard let result = try? JSONSerialization.jsonObject(with: data, options: [])  as? [String: Any] else {
                completion (nil,nil,"Coulding parase the data")
                return
            }
            
            guard let stat = result["stat"] as? String, stat == "ok" else {
                completion(nil,nil,"Flicker not connect")
                return
            }
            
            guard let photoDictionary = result["photos"] as? [String:Any] else {
                completion(nil,nil,"There is no photo result")
                return
            }
            
            
            guard let photoArray = photoDictionary["photo"] as? [[String:Any]] else {
                completion(nil,nil,"No arrary")
                return
            }
            
            let photoURLs = photoArray.compactMap{ photoDictionary -> URL? in
                guard let url = photoDictionary["url_m"] as? String else {
                    return nil
                }
                return URL(string: url)
            }
            
            
            completion(photoURLs,nil,nil)
            
        }
        task.resume()
    }
    static func constructURL(from parameters: [String: Any]) -> URL {
        
        var components = URLComponents()
        components.scheme = "https"
        components.host = "api.flickr.com"
        components.path = "/services/rest"
        components.queryItems = [URLQueryItem]()
        
        for (key, value) in parameters {
            let queryItem = URLQueryItem(name: key, value: "\(value)")
            components.queryItems!.append(queryItem)
        }
        
        return components.url!
    }
    
    static func getBboxInfo(latitude: Double, longitude: Double) -> String {
        // ensure bbox is bounded by minimum and maximums
        let minimumLon = max(longitude - 0.1 , -180)
        let minimumLat = max(latitude  - 0.1 , -90)
        let maximumLon = min(longitude + 0.1 , 180)
        let maximumLat = min(latitude  + 0.1 , 90)
        return "\(minimumLon),\(minimumLat),\(maximumLon),\(maximumLat)"
    }
}


