//
//  PhotoCell.swift
//  virtualTourist
//
//  Created by Raed Faraj on 6/14/19.
//  Copyright © 2019 Udacity. All rights reserved.
//

import UIKit

class PhotoCell: UICollectionViewCell {
    
    var urlString: String?
    
    @IBOutlet weak var locationPhoto: UIImageView!
    
    override func prepareForReuse() {
        super.prepareForReuse()
    }
    
    lazy var activityIndicatorview: UIActivityIndicatorView = {
        let activityIndicatorview = UIActivityIndicatorView(style: .whiteLarge)
        self.addSubview(activityIndicatorview)
        activityIndicatorview.translatesAutoresizingMaskIntoConstraints = false
        activityIndicatorview.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        activityIndicatorview.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        activityIndicatorview.color = .black
        activityIndicatorview.hidesWhenStopped = true
        return activityIndicatorview
    }()
    
    
    func showActivityIndicatorView() {
        DispatchQueue.main.async {
            self.activityIndicatorview.startAnimating()
        }
    }
    
    func hideActivityIndicatorView() {
        DispatchQueue.main.async {
            self.activityIndicatorview.stopAnimating()
        }
    }
}
